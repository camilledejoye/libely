#ifndef CONNECT_HPP
#define CONNECT_HPP


namespace ely
{
namespace signals_slots
{


template < typename ... Args > class  Signal;
template < typename ... Args > class  AbstractCallableObject;


template < typename ... Args >
void connect( Signal< Args ... > & aSignal, AbstractCallableObject< Args ... > & callableObject );

template < typename ... Args >
void disconnect( Signal< Args ... > & aSignal, AbstractCallableObject< Args ... > & callableObject );


} // namespace signals_slots
} // namespace ely


#include "ely/signals_slots/connect.tpp"

#endif // CONNECT_HPP
