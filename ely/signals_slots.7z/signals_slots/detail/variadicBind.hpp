#ifndef VARIADIC_BIND_HPP
#define VARIADIC_BIND_HPP


#include <type_traits>


namespace ely
{
namespace signals_slots
{
namespace detail
{


template < int N > struct PlaceHolders {};


template < ::std::size_t ... Is > struct IntegerSequence {};

template < ::std::size_t N, ::std::size_t ... Is >
struct BuildSequence
    : BuildSequence< N - 1, N - 1, Is ... >
{};
template < ::std::size_t ... Is >
struct BuildSequence< 0, Is ... >
    : IntegerSequence< Is ... >
{};


template< ::std::size_t ... Sequence,
          typename Function,
          typename ... Args >
auto variadicBindSequence( IntegerSequence< Sequence ... >,
                           Function f,
                           Args && ... args )
    -> decltype( ::std::bind( f, ::std::forward< Args >( args ) ..., PlaceHolders< Sequence + 1 >{} ... ) )
{
    return ::std::bind( f,
                        ::std::forward< Args >( args ) ...,
                        PlaceHolders< Sequence + 1 >{} ... );
}


template< typename ReturnType,
          typename ... FunctionArgsType,
          typename ... Args >
auto variadicBind( ::std::function< ReturnType( FunctionArgsType ... ) > f,
                   Args && ... args )
    -> decltype( detail::variadicBindSequence( detail::BuildSequence< sizeof...( FunctionArgsType ) - sizeof...( Args ) >{}, f, ::std::forward< Args >( args ) ... ) )
{
    return detail::variadicBindSequence( detail::BuildSequence< sizeof...( FunctionArgsType ) -
                                                                sizeof...( Args ) >{},
                                         f,
                                         ::std::forward< Args >( args ) ... );
}


} // namespace detail


} // namespace signals_slots
} // namespace ely


namespace std
{


template < int N >
struct is_placeholder< ::ely::signals_slots::detail::PlaceHolders< N > >
    : ::std::integral_constant< int, N >
{};


} // namespace std


#endif // VARIADIC_BIND_HPP

